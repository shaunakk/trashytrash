module.exports = {
    consumer_key:         'Z06o6VReH5lGHLQFnWjdZkfGh',
    consumer_secret:      'dW0C9LfDDLp5dXFBb1bQ4F7nw3CP3YquBW1111VkkA4QYC05oU',
    app_only_auth:        true
}
