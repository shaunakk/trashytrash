module.exports = {
    region:'us-east-1',
    accessKeyId: 'AKIAIZHWGMO4BYFIPAAQ',
    secretAccessKey: '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'
}
