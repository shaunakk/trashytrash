module.exports = {
    region:'us-east-1',
    accessKeyId: 'AKIAIYR7BHSW5ODZVJXQ',
    secretAccessKey: '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'
}
