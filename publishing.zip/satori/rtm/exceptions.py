
class AuthError(RuntimeError):
    pass