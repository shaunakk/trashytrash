#!/bin/bash

zip -r ../publishing.zip *
