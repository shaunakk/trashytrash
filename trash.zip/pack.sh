#!/bin/bash

zip -r ../trash.zip *
