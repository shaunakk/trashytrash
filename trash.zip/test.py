keywords = ["Trash", "Bottle", "Can", "Rubble", "Tin", "Paper", "Plastic"]

def filter(labels):
    res = []
    for l in labels:
        if l["name"] in keywords:
            res.append(l["name"])
    return res

labels = [
        {
        "name": "Bottle"
        },
        {
        "name": "a"
        }
    ]

res = filter(labels)
print(res)
